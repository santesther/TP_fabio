package ProgramaDisponibilizado2;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class arquivoTextoDeJogos implements ArquivoDeJogos { //classe implementa a interface ArquivoDeJogos ent segue o contrato(métodos) que estão nela.

	String nomeDoArquivo = "D:/Desktop/jogosSerializados.txt";
	
	@Override
	public void lerDoArquivoParaMemoria(ColecaoDeJogos listaDeJogos) { 
		FileReader arquivoDeEntrada = null;
		BufferedReader leituraBufferizada;
		String linhaLidaDoArquivo;
		Jogo jogo;
		
		try {
			arquivoDeEntrada = new FileReader(nomeDoArquivo); // fileReader vai receber o arquivo jogosSerializados.txt
			leituraBufferizada = new BufferedReader(arquivoDeEntrada); // bufferedReader vai ler esse arquivo de entrada.

			linhaLidaDoArquivo = leituraBufferizada.readLine();
			while (linhaLidaDoArquivo != null) 
			{
				jogo = criarObjetoJogo(linhaLidaDoArquivo); // com cada linha de texto, pegar os campos e transformar em um objeto então se criou o método criarObjetoJogo.
				listaDeJogos.adicionarJogo(jogo); //add o jogo q que acaboiu de ler do arquivo
				linhaLidaDoArquivo = leituraBufferizada.readLine(); // pega um novo jogo e adiciona, fica nesse loop //chama o próprio método enquanto a linha não for vazia. //essa chamada se eu não estou enganada lembra um pouco ate a recursividade
			}
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado!"); // em caso de não encontrar o arquivo que está no caminho do arquivoDeEntrada
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Erro de entrada e saída!"); // caso de IOException //se o diretório estiver errado por exemplo.
			e.printStackTrace();
		} 
	}
	
	private Jogo criarObjetoJogo(String linhaLidaDoArquivo) { //recebe a linha lida do arquivo
		String nomeDoJogo, plataforma;
		int ano;
		double vendasGlobais;
		String camposDoArquivo[];
		camposDoArquivo = linhaLidaDoArquivo.split(","); // método que vai quebrar a string inteira e transformar num vetor de strings
		nomeDoJogo = camposDoArquivo[0];
		plataforma = camposDoArquivo[1];
		ano = Integer.parseInt(camposDoArquivo[2]);			
		vendasGlobais = Double.parseDouble(camposDoArquivo[3]); // colocar cada uma dessas quebras de linha como sendo um dos campos do objeto
		return new Jogo(nomeDoJogo, plataforma, ano, vendasGlobais); // cria objeto contendo esses campos e retorna isso pra quem chamou, que foi o jogo=criarObjetoJogo(linhaLidaDoArquivo)
	}

	@Override
	public void escreverDaMemoriaNoArquivo(ColecaoDeJogos listaDeJogos) { // precisa do método pois implementa a interface ArquivoDeJogos
		FileWriter arquivoDeSaida = null;
		String nomeDoJogo, plataforma;
		int ano;
		double vendasGlobais;
		try {
			arquivoDeSaida = new FileWriter(nomeDoArquivo);
			int totalDeJogos = listaDeJogos.obterTotalDeJogos();
			
			for (int indiceDoJogo = 0; indiceDoJogo < totalDeJogos; indiceDoJogo++) { // loop passando pela lista de jogos
				nomeDoJogo = listaDeJogos.obterJogo(indiceDoJogo).obterNome(); // pega nome	
				plataforma = listaDeJogos.obterJogo(indiceDoJogo).obterPlataforma(); //pega plataforma
				ano = listaDeJogos.obterJogo(indiceDoJogo).obterAno(); //pega ano
				vendasGlobais = listaDeJogos.obterJogo(indiceDoJogo).obterVendasGlobais(); // pega vendas globais
				arquivoDeSaida.write(nomeDoJogo + "," + plataforma + "," + ano + "," + vendasGlobais + "\n"); // imprimindo cada um dos campos com um método ja incluso no FileWriter fznd concatenação com as infos q pegou no loop e gravando no arquivo
				//concatenando informações com a vírgula para permitir leitura posterior para poder usar como parâmetro no split.
			}
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado!"); //se o arquivo não existir ou o caminho estiver errado vai ocorrer um erro do tipo fileNotFoundException
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("Erro de entrada e saída!"); //se o diretório estiver errado o programa não vai rodar e vai aparecer a msg que o arquivo não foi encontrado.
			e.printStackTrace();
		}
		
		try {
			arquivoDeSaida.close();
		} 
		catch (IOException e) {
			System.out.println("Erro de entrada e saída!"); 
			e.printStackTrace();
		} 
		catch (NullPointerException e) {
			System.out.println("Erro: Arquivo não encontrado!");
			e.printStackTrace();
		}
	}
}
