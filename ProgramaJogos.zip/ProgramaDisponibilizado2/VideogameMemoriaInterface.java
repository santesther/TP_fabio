package ProgramaDisponibilizado2;

import java.util.Scanner;

public class VideogameMemoriaInterface {

	public static void main(String[] args) {
		Scanner entradaDoTeclado = new Scanner(System.in);
		int opcaoArmazenamentoEmMemoria, opcaoMenuPrincipal;
		ColecaoDeJogos listaDeJogos;
		ArquivoDeJogos arquivoDeJogos;
		System.out.println("1 - Vetor");
		System.out.println("2 - ArrayList");
		System.out.println("Qual a estrutura de armazenamento em memória você deseja utilizar?"); // duas opções de armazenamento que seguem a interface coleçãoDeJogos. A classe principal segue então o contrato(contém os métodos) que estão na contidos interface.
		opcaoArmazenamentoEmMemoria = entradaDoTeclado.nextInt();
		if (opcaoArmazenamentoEmMemoria == 1) 
		{
			listaDeJogos = new VetorDeJogos();
		} else
		{
			listaDeJogos = new ArrayListDeJogos();
		}
		
		do {
			System.out.println("\n\n*************** Menu de Opções ****************");
			System.out.println("1 - Adicionar jogo");
			System.out.println("2 - Excluir jogo");
			System.out.println("3 - Listar jogos");
			System.out.println("4 - Ordenar jogos por ano");
			System.out.println("5 - Ordenar jogos por vendas globais");
			System.out.println("6 - Buscar jogo por nome");
			System.out.println("7 - Escrever txt em arquivo");
			System.out.println("8 - Escrever serial em arquivo");
			System.out.println("9 - ler jogo serializado do arquivo");
			System.out.println("10 - ler jogo do arquivo de texto");
			System.out.println("0 - Sair do programa");
			opcaoMenuPrincipal = entradaDoTeclado.nextInt();
			switch (opcaoMenuPrincipal) {
				case 1:
					adicionarJogo(listaDeJogos);
					break;
				case 2:
					excluirJogo(listaDeJogos);
					break;
				case 3:
					listarJogos(listaDeJogos);
					break;
				case 4:
					ordenarJogosPorAno(listaDeJogos);
					break;
				case 5:
					ordenarJogosPorVendasGlobais(listaDeJogos);
					break;
				case 6:
					buscarJogoPorNome(listaDeJogos);
					break;
				case 7:
					arquivoDeJogos = new arquivoTextoDeJogos();
					escreverDaMemoriaNoArquivo(arquivoDeJogos, listaDeJogos);
					break;
				case 8:
				    arquivoDeJogos = new tratamentoDeDados();
					escreverDaMemoriaNoArquivoSerial(arquivoDeJogos, listaDeJogos);	
					break;
				case 9: 
				    arquivoDeJogos = new tratamentoDeDados();
				    lerDoArquivoParaMemoria(arquivoDeJogos, listaDeJogos);
					break;
				case 10:
				    arquivoDeJogos = new arquivoTextoDeJogos();
				    lerDoArquivoParaMemoria(arquivoDeJogos, listaDeJogos);	
			}
		} while (opcaoMenuPrincipal != 0);
		
	}

	private static void adicionarJogo(ColecaoDeJogos listaDeJogos) { //recebe como parâmetro a lista de jogos
		Scanner entradaDoTeclado = new Scanner(System.in);
		String nome, plataforma;
		int ano;
		double vendasGlobais;

		System.out.println("Entre com o nome do jogo:");
		nome = entradaDoTeclado.nextLine();
		System.out.println("Entre com a plataforma:");
		plataforma = entradaDoTeclado.nextLine();
		System.out.println("Entre com o ano de lançamento:");
		ano = entradaDoTeclado.nextInt();
		System.out.println("Entre com o total de vendas globais:");
		vendasGlobais = entradaDoTeclado.nextDouble();
		Jogo jogo1 = new Jogo(nome, plataforma, ano, vendasGlobais); // vai retornar um novo jogo com as informações que pediu
		listaDeJogos.adicionarJogo(jogo1); // esse jogo vai ser adicionado na lista de jogos, ele passa como parâmetro
	}

	private static void excluirJogo(ColecaoDeJogos listaDeJogos) {
		boolean excluiu;

		excluiu = listaDeJogos.excluirJogo();
		if (excluiu == true) 
		{
			System.out.println("Jogo excluído com sucesso.");
		} else 
		{
			System.out.println("Jogo não encontrado.");
		}
	}

	private static void listarJogos(ColecaoDeJogos listaDeJogos) {
		int totalDeJogos = listaDeJogos.obterTotalDeJogos();
		if (totalDeJogos > 0) 
		{
			Jogo jogo;
			for (int indiceDoJogo = 0; indiceDoJogo < totalDeJogos; indiceDoJogo++) 
			{
				jogo = listaDeJogos.obterJogo(indiceDoJogo);
				System.out.println("\n------------------------------------------");
				System.out.println("Nome do Jogo:" + jogo.obterNome());
				System.out.println("Plataforma:" + jogo.obterPlataforma());
				System.out.println("Ano de lançamento:" + jogo.obterAno());
				System.out.println("Total de vendas globais:" + jogo.obterVendasGlobais());
			}
		} else 
		{
			System.out.println("Não existem jogos cadastrados na lista.");
		}
	}

	private static void ordenarJogosPorAno(ColecaoDeJogos listaDeJogos) {
		listaDeJogos.ordenarJogosPorAno();
	}

	private static void ordenarJogosPorVendasGlobais(ColecaoDeJogos listaDeJogos) {
		listaDeJogos.ordenarJogosPorVendasGlobais();
	}

	private static void buscarJogoPorNome(ColecaoDeJogos listaDeJogos) {
		Jogo jogoBuscado = listaDeJogos.buscarJogoPorNome();
		if (jogoBuscado != null) 
		{
			
			System.out.println("\n------------------------------------------");
			System.out.println("Nome do Jogo:" + jogoBuscado.obterNome());
			System.out.println("Plataforma:" + jogoBuscado.obterPlataforma());
			System.out.println("Ano de lançamento:" + jogoBuscado.obterAno());
			System.out.println("Total de vendas globais:" + jogoBuscado.obterVendasGlobais());
		} else 
		{
			System.out.println("O jogo não foi encontrado");
		}
	}

	private static void escreverDaMemoriaNoArquivo(ArquivoDeJogos arquivoDeJogos, ColecaoDeJogos listaDeJogos) {
		arquivoDeJogos.escreverDaMemoriaNoArquivo(listaDeJogos);
	}

	private static void escreverDaMemoriaNoArquivoSerial(ArquivoDeJogos arquivoDeJogos, ColecaoDeJogos listaDeJogos) {
		arquivoDeJogos.escreverDaMemoriaNoArquivo(listaDeJogos);
	}

	private static void lerDoArquivoParaMemoria(ArquivoDeJogos arquivoDeJogos, ColecaoDeJogos listaDeJogos) {
		arquivoDeJogos.lerDoArquivoParaMemoria(listaDeJogos);
	}
}