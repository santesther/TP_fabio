package ProgramaDisponibilizado2;

import java.util.Scanner;


public class VetorDeJogos implements ColecaoDeJogos {
	Jogo listaDeJogos[];
	int totalDeJogos;

	public VetorDeJogos() {
		this.listaDeJogos = new Jogo[17000];
		this.totalDeJogos = 0;
	}

	public VetorDeJogos(int tamanhoMaximoDaLista) {
		this.listaDeJogos = new Jogo[tamanhoMaximoDaLista];
		this.totalDeJogos = 0;
	}

	@Override
	public void adicionarJogo(Jogo jogo) {
		this.listaDeJogos[totalDeJogos] = jogo;
		this.totalDeJogos++;
	}

	@Override
	public boolean excluirJogo() {
		if (this.totalDeJogos > 0) // se o total de jogos for maior que zero vai retirar a ultima posição e retornar true, se não for maior que zero(eh pq nao tem jogos) aí vai retornar false
		{
			this.totalDeJogos--;
			return true;
		}
		return false;
	}

	@Override
	public Jogo obterJogo(int indiceDoJogo) {
		return this.listaDeJogos[indiceDoJogo];
	}

	@Override
	public int obterTotalDeJogos() {
		return this.totalDeJogos;
	}

	@Override
	public void ordenarJogosPorAno() {
		boolean existiuTroca = true;
		int analise = 0;
		if (totalDeJogos > 0) 
		{
			do {
				existiuTroca = false;
				for (int indiceDoJogo = 0; indiceDoJogo < totalDeJogos; indiceDoJogo++) 
				{
					if (indiceDoJogo + 1 < totalDeJogos) // para haver troca
					{
						if (listaDeJogos[indiceDoJogo].obterAno() > listaDeJogos[indiceDoJogo + 1].obterAno()) 
						{
							Jogo auxiliarTrocaJogo;
							auxiliarTrocaJogo = this.listaDeJogos[indiceDoJogo];
							listaDeJogos[indiceDoJogo] = this.listaDeJogos[indiceDoJogo + 1];
							this.listaDeJogos[indiceDoJogo + 1] = auxiliarTrocaJogo;
							existiuTroca = true;
							analise++; // se ocorrer troca o analise vai ser diferente de 0 e isso vai parar o loop.
						}
					}
				}
			} while (existiuTroca);
		}
		System.out.println("jogos ordenados por ano");
	}

	@Override
	public void ordenarJogosPorVendasGlobais() {
		boolean existiuTroca = true;
		int analise = 0;
		if (totalDeJogos > 0) 
		{
			do 
			{
				existiuTroca = false;
				for (int indiceDoJogo = 0; indiceDoJogo < totalDeJogos; indiceDoJogo++) 
				{
					if (indiceDoJogo + 1 < totalDeJogos) 
					{
						if (listaDeJogos[indiceDoJogo].obterVendasGlobais() > listaDeJogos[indiceDoJogo + 1].obterVendasGlobais()) 
						{
							Jogo auxiliarTrocaJogo;
							auxiliarTrocaJogo = this.listaDeJogos[indiceDoJogo];
							listaDeJogos[indiceDoJogo] = this.listaDeJogos[indiceDoJogo + 1];
							this.listaDeJogos[indiceDoJogo + 1] = auxiliarTrocaJogo;
							existiuTroca = true;
							analise++;
						}
					}
				}
			} while (existiuTroca);
		}
		System.out.println("Jogos ordenados por vendas globais");
	}

	@Override
	public Jogo buscarJogoPorNome() {
		Scanner entradaDoTeclado = new Scanner(System.in);
		System.out.println("Digite o nome do jogo que você deseja encontrar");
		String jogoABuscar = entradaDoTeclado.nextLine();

		for (int indiceDoJogo = 0; indiceDoJogo < totalDeJogos; indiceDoJogo++) 
		{
			if (jogoABuscar.equals(listaDeJogos[indiceDoJogo].obterNome())) 
			{
				return listaDeJogos[indiceDoJogo];
			}
		}
		return null;
	}
}
