package ProgramaDisponibilizado2;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;


public class tratamentoDeDados implements ArquivoDeJogos{ // classe tem os métodos contidos na interface arquivoDeJogos pois implementa a interface
	private String nomeDoArquivo = "D:/Desktop/jogosSerializados2.bin"; //esse arquivo ja tem q existir

	public void lerDoArquivoParaMemoria(ColecaoDeJogos listaDeJogos) { //recebe os jogos da coleçãoDeJogos como parâmetro
		try {
		    Jogo jogo = null; //ler objeto que tá no arquivo e vai passar pra arraylist ou vetor etc.
			ObjectInputStream arquivo = new ObjectInputStream(new FileInputStream(nomeDoArquivo)); //leitura e escrita serial de objetos são acoplados a um fluxo principal. ent define o fluxo de leitura. //fileInputStream faz a conexão com um arquivo.
			do {
				jogo = (Jogo) arquivo.readObject(); //vai receber o jogo que ta dentro do arquivo.
				if (jogo != null) //se n for vazio
				{
					listaDeJogos.adicionarJogo(jogo); //vai add o jogo na coleçãoDeJogos jogos
				}
			} while (jogo != null); // esse loop acontece enquanto jogo for diferente de null(vazio).
			arquivo.close(); // <----   qnd o jogo for nulo
		} catch (IOException e) {
			System.out.println(e.getMessage()); //se o arquivo não existir vai dar o fileNotFoundException e vai aparecer a msg que o arquivo não pode ser encontrado
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage()); //se por exempo o diretorio estiver errado vai aparecer a msg A sintaxe do nome do arquivo, do nome do diretório ou do rótulo do volume está incorreta, erro do tipo classNotFoundException.
		}
	}

	@Override
	public void escreverDaMemoriaNoArquivo(ColecaoDeJogos listaDeJogos) {
		int indiceDoJogo = 0;
		ObjectOutputStream arquivoParaEscrita = null;
		try {
			arquivoParaEscrita =  new ObjectOutputStream(new FileOutputStream(nomeDoArquivo)); // faz a escrita serial de objetos, nesse caso os jogos. // fileOutputStream cria um arquivo para receber essas informações.
			for (; indiceDoJogo < listaDeJogos.obterTotalDeJogos(); indiceDoJogo++) {
				//Jogo jogo = listaDeJogos.obterJogo(indiceDoJogo); //feito para melhorar a leitura porém variável jogo não é necessária.
				arquivoParaEscrita.writeObject(listaDeJogos.obterJogo(indiceDoJogo)); //faz a escrita cm os objetos que recebe. 
			}
			arquivoParaEscrita.close();
		} catch (IOException e) {
			System.out.println(e.getMessage()); //caso de erro no input ou output //por ex: se o diretorio nao existir aí vai aparecer a msg A sintaxe do nome do arquivo, do nome do diretório ou do rótulo do volume está incorreta
		}
		
	}
}
