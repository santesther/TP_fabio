package ProgramaDisponibilizado2;

public interface metodosDeBusca {

    public Jogo buscarNome(ColecaoDeJogos listaDeJogos);

    public int buscarNomeNoVetor(Jogo[] listaDeJogos, int totalDeJogos);
}
