package ProgramaDisponibilizado2;

public interface ArquivoDeJogos {

	void lerDoArquivoParaMemoria(ColecaoDeJogos listaDeJogos);

	void escreverDaMemoriaNoArquivo(ColecaoDeJogos listaDeJogos, int tipo);

}
